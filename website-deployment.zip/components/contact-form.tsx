"use client"

import React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowRight, CheckCircle2, Loader2 } from "lucide-react"

export function ContactForm() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    message: ""
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError("")

    try {
      // Simulate sending - in production, connect to email service
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      setIsSubmitted(true)
      setFormData({ firstName: "", lastName: "", email: "", message: "" })
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isSubmitted) {
    return (
      <Card className="bg-[#111111] border-[#222222] p-8 rounded-2xl">
        <div className="text-center py-12">
          <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-8 h-8 text-green-400" />
          </div>
          <h3 className="text-2xl font-bold mb-2 text-white">Sent</h3>
          <Button
            onClick={() => setIsSubmitted(false)}
            variant="outline"
            className="border-[#ff6b00]/30 text-[#ff6b00] hover:bg-[#ff6b00]/10 bg-transparent mt-4"
          >
            Send Another Message
          </Button>
        </div>
      </Card>
    )
  }

  return (
    <Card className="bg-[#111111] border-[#222222] p-8 rounded-2xl">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-white/60 mb-2">First Name</label>
            <input
              type="text"
              required
              value={formData.firstName}
              onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
              className="w-full px-4 py-3 rounded-xl bg-[#1a1a1a] border border-[#333333] text-white placeholder-white/30 focus:outline-none focus:border-[#ff6b00] transition-colors"
              placeholder="Enter your first name"
            />
          </div>
          <div>
            <label className="block text-sm text-white/60 mb-2">Last Name</label>
            <input
              type="text"
              required
              value={formData.lastName}
              onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
              className="w-full px-4 py-3 rounded-xl bg-[#1a1a1a] border border-[#333333] text-white placeholder-white/30 focus:outline-none focus:border-[#ff6b00] transition-colors"
              placeholder="Enter your last name"
            />
          </div>
        </div>
        <div>
          <label className="block text-sm text-white/60 mb-2">Email</label>
          <input
            type="email"
            required
            value={formData.email}
            onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
            className="w-full px-4 py-3 rounded-xl bg-[#1a1a1a] border border-[#333333] text-white placeholder-white/30 focus:outline-none focus:border-[#ff6b00] transition-colors"
            placeholder="Enter your email"
          />
        </div>
        <div>
          <label className="block text-sm text-white/60 mb-2">Message</label>
          <textarea
            rows={4}
            required
            value={formData.message}
            onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
            className="w-full px-4 py-3 rounded-xl bg-[#1a1a1a] border border-[#333333] text-white placeholder-white/30 focus:outline-none focus:border-[#ff6b00] transition-colors resize-none"
            placeholder="How can we help you?"
          />
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
            {error}
          </div>
        )}

        <Button 
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-[#ff6b00] hover:bg-[#ff8533] text-black font-semibold py-6 rounded-xl transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,107,0,0.4)] disabled:opacity-50"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 w-5 h-5 animate-spin" />
              Sending...
            </>
          ) : (
            <>
              Send Message
              <ArrowRight className="ml-2 w-5 h-5" />
            </>
          )}
        </Button>
      </form>
    </Card>
  )
}
