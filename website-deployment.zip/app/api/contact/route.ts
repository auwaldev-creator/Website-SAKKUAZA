import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { firstName, lastName, email, message } = await request.json()

    // Validate required fields
    if (!firstName || !lastName || !email || !message) {
      return NextResponse.json(
        { error: "All fields are required" },
        { status: 400 }
      )
    }

    // Create mailto link data for client-side handling
    // In production, you would use a service like Resend, SendGrid, or Nodemailer
    const mailtoData = {
      to: "sakkuazageneralservice@gmail.com",
      subject: `Contact Form: Message from ${firstName} ${lastName}`,
      body: `Name: ${firstName} ${lastName}\nEmail: ${email}\n\nMessage:\n${message}`,
      success: true
    }

    return NextResponse.json(mailtoData)
  } catch (error) {
    console.error("Contact form error:", error)
    return NextResponse.json(
      { error: "Failed to process request" },
      { status: 500 }
    )
  }
}
