"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { 
  Menu, 
  X, 
  ArrowRight, 
  Shield, 
  Zap, 
  Globe, 
  Users, 
  ChevronDown,
  ExternalLink,
  Smartphone,
  Fingerprint,
  Network,
  Coins,
  Building2,
  CheckCircle2
} from "lucide-react"
import Link from "next/link"
import { ContactForm } from "@/components/contact-form"

// Partner data with real links
const partners = [
  {
    name: "MTN Nigeria",
    logo: "MTN",
    description: "Africa's largest telecom network",
    url: "https://www.mtn.ng/",
    color: "#FFCC00"
  },
  {
    name: "Airtel Nigeria",
    logo: "Airtel",
    description: "Connecting Nigeria digitally",
    url: "https://www.airtel.com.ng/",
    color: "#FF0000"
  },
  {
    name: "NIMC",
    logo: "NIMC",
    description: "National Identity Management",
    url: "https://nimc.gov.ng/",
    color: "#008751"
  },
  {
    name: "Sidra Clubs",
    logo: "Sidra",
    description: "Official KYB Approved Partner - We provide KYC verification on Sidra Blockchain",
    url: "https://www.sidraclubs.com/",
    color: "#00D4FF",
    badge: "APPROVED"
  },
  {
    name: "Pi Network",
    logo: "Pi",
    description: "Next generation cryptocurrency",
    url: "https://minepi.com/",
    color: "#7B4BC2"
  }
]

const features = [
  {
    icon: Fingerprint,
    title: "Digital Identity",
    description: "Secure blockchain-based identity verification integrated with NIMC for seamless authentication."
  },
  {
    icon: Shield,
    title: "Security First",
    description: "Military-grade encryption protecting your data with decentralized storage solutions."
  },
  {
    icon: Smartphone,
    title: "Mobile Integration",
    description: "Seamless connectivity with MTN and Airtel networks for instant verification."
  },
  {
    icon: Coins,
    title: "Crypto Ready",
    description: "Full integration with Pi Network and Sidra for digital asset management."
  },
  {
    icon: Network,
    title: "Business Dashboard",
    description: "Create and manage your business with our powerful management dashboard and analytics tools."
  },
  {
    icon: Globe,
    title: "Pan-African Vision",
    description: "Expanding digital infrastructure across Nigeria and beyond."
  }
]

const stats = [
  { value: "10M+", label: "Users Protected" },
  { value: "5", label: "Major Partners" },
  { value: "99.9%", label: "Uptime" },
  { value: "100%", label: "Secure" }
]

export default function HomePage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [activeSection, setActiveSection] = useState("home")

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
      
      // Update active section based on scroll position
      const sections = ["home", "features", "partners", "about", "contact"]
      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const rect = element.getBoundingClientRect()
          if (rect.top <= 100 && rect.bottom >= 100) {
            setActiveSection(section)
            break
          }
        }
      }
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white overflow-x-hidden">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "bg-[#0a0a0a]/95 backdrop-blur-xl border-b border-[#ff6b00]/20" : "bg-transparent"
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#ff6b00] to-[#ff8533] flex items-center justify-center font-bold text-black text-lg group-hover:scale-110 transition-transform duration-300">
                S
              </div>
              <span className="text-xl font-bold tracking-tight">
                SAKKU<span className="text-[#ff6b00]">AZA</span>
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {["Home", "Features", "Partners", "About", "Contact"].map((item) => (
                <Link
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className={`text-sm font-medium transition-all duration-300 hover:text-[#ff6b00] relative ${
                    activeSection === item.toLowerCase() ? "text-[#ff6b00]" : "text-white/80"
                  }`}
                >
                  {item}
                  {activeSection === item.toLowerCase() && (
                    <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#ff6b00] rounded-full" />
                  )}
                </Link>
              ))}
            </div>

            {/* CTA Button */}
            <div className="hidden md:flex items-center gap-4">
              <Button 
                className="bg-[#ff6b00] hover:bg-[#ff8533] text-black font-semibold px-6 rounded-full transition-all duration-300 hover:scale-105 hover:shadow-[0_0_30px_rgba(255,107,0,0.4)]"
              >
                Get Started
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-white/10 transition-colors"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div className={`md:hidden absolute top-full left-0 right-0 bg-[#0a0a0a]/98 backdrop-blur-xl border-b border-[#ff6b00]/20 transition-all duration-300 ${
          isMenuOpen ? "opacity-100 visible" : "opacity-0 invisible"
        }`}>
          <div className="px-4 py-6 space-y-4">
            {["Home", "Features", "Partners", "About", "Contact"].map((item) => (
              <Link
                key={item}
                href={`#${item.toLowerCase()}`}
                onClick={() => setIsMenuOpen(false)}
                className="block py-3 text-lg font-medium hover:text-[#ff6b00] transition-colors"
              >
                {item}
              </Link>
            ))}
            <Button className="w-full bg-[#ff6b00] hover:bg-[#ff8533] text-black font-semibold rounded-full mt-4">
              Get Started
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-b from-[#ff6b00]/10 via-transparent to-transparent" />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#ff6b00]/20 rounded-full blur-[120px] animate-pulse-glow" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#00d4ff]/10 rounded-full blur-[120px] animate-pulse-glow delay-500" />
          
          {/* Grid Pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,107,0,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,107,0,0.03)_1px,transparent_1px)] bg-[size:60px_60px]" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Animated Company Name */}
          <div className="mb-6 animate-slide-up">
            <h2 className="text-lg sm:text-xl md:text-2xl font-bold animate-color-shift">
              SAKKUAZA GENERAL SERVICES NIG LTD
            </h2>
          </div>
          
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#ff6b00]/10 border border-[#ff6b00]/30 mb-8 animate-slide-up">
            <span className="w-2 h-2 bg-[#ff6b00] rounded-full animate-pulse" />
            <span className="text-sm text-[#ff6b00] font-medium">Powering Nigeria&apos;s Digital Future</span>
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold leading-tight mb-6 animate-slide-up delay-100">
            <span className="block">Blockchain &</span>
            <span className="block bg-gradient-to-r from-[#ff6b00] via-[#ffa500] to-[#00d4ff] bg-clip-text text-transparent animate-gradient">
              Digital Identity
            </span>
            <span className="block">Solutions</span>
          </h1>

          {/* Subtitle */}
          <p className="text-lg sm:text-xl text-white/60 max-w-2xl mx-auto mb-10 animate-slide-up delay-200">
            Secure, scalable blockchain infrastructure connecting Nigeria&apos;s digital ecosystem with trusted partners like MTN, Airtel, NIMC, Pi Network, and Sidra.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up delay-300">
            <Button 
              size="lg"
              className="bg-[#ff6b00] hover:bg-[#ff8533] text-black font-semibold px-8 py-6 text-lg rounded-full transition-all duration-300 hover:scale-105 hover:shadow-[0_0_40px_rgba(255,107,0,0.5)] w-full sm:w-auto"
            >
              Explore Ecosystem
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="border-white/20 text-white hover:bg-white/10 px-8 py-6 text-lg rounded-full w-full sm:w-auto bg-transparent"
            >
              Read Whitepaper
              <ChevronDown className="ml-2 w-5 h-5" />
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20 animate-slide-up delay-400">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl sm:text-4xl font-bold text-[#ff6b00] mb-1">{stat.value}</div>
                <div className="text-sm text-white/50">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronDown className="w-8 h-8 text-[#ff6b00]/50" />
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#ff6b00]/5 to-transparent" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-16">
            <span className="inline-block px-4 py-1.5 rounded-full bg-[#ff6b00]/10 border border-[#ff6b00]/30 text-[#ff6b00] text-sm font-medium mb-4">
              Features
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              Built for the <span className="text-[#ff6b00]">Future</span>
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto">
              Cutting-edge technology powering Nigeria&apos;s digital transformation with security, speed, and scalability.
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card 
                key={index}
                className="group bg-[#111111] border-[#222222] hover:border-[#ff6b00]/50 p-8 rounded-2xl transition-all duration-500 hover:translate-y-[-8px] hover:shadow-[0_20px_60px_rgba(255,107,0,0.15)]"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#ff6b00]/20 to-[#ff6b00]/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 animate-icon-color">
                  <feature.icon className="w-7 h-7 transition-colors duration-500" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-white group-hover:animate-color-shift transition-all">{feature.title}</h3>
                <p className="text-white/60 leading-relaxed">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Partners Section */}
      <section id="partners" className="py-24 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#ff6b00]/30 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#ff6b00]/30 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-16">
            <span className="inline-block px-4 py-1.5 rounded-full bg-[#00d4ff]/10 border border-[#00d4ff]/30 text-[#00d4ff] text-sm font-medium mb-4">
              Trusted Partners
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
              Our <span className="text-[#00d4ff]">Ecosystem</span>
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto">
              Partnering with Nigeria&apos;s leading organizations to build a connected, secure digital future.
            </p>
          </div>

          {/* Partners Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {partners.map((partner, index) => (
              <Link
                key={index}
                href={partner.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group"
              >
                <Card className="bg-[#111111] border-[#222222] hover:border-[#ff6b00]/50 p-8 rounded-2xl transition-all duration-500 hover:translate-y-[-8px] hover:shadow-[0_20px_60px_rgba(255,107,0,0.15)] h-full">
                  <div className="flex items-start justify-between mb-6">
                    <div 
                      className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-bold transition-all duration-300 group-hover:scale-110"
                      style={{ 
                        backgroundColor: `${partner.color}20`,
                        color: partner.color
                      }}
                    >
                      {partner.logo}
                    </div>
                    <div className="flex items-center gap-2">
                      {"badge" in partner && partner.badge && (
                        <span className="px-2 py-1 text-xs font-bold bg-green-500/20 text-green-400 rounded-full flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          {partner.badge}
                        </span>
                      )}
                      <ExternalLink className="w-5 h-5 text-white/30 group-hover:text-[#ff6b00] transition-colors" />
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold mb-2 text-white group-hover:text-[#ff6b00] transition-colors">
                    {partner.name}
                  </h3>
                  <p className="text-white/50">{partner.description}</p>
                  <div className="mt-4 flex items-center gap-2 text-sm text-[#ff6b00] opacity-0 group-hover:opacity-100 transition-opacity">
                    <span>Visit Website</span>
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </Card>
              </Link>
            ))}
          </div>

          {/* Partner Logos Marquee */}
          <div className="mt-20 relative overflow-hidden">
            <div className="flex items-center gap-16 animate-[slide-in-left_20s_linear_infinite]">
              {[...partners, ...partners].map((partner, index) => (
                <div 
                  key={index}
                  className="flex-shrink-0 text-3xl font-bold opacity-30 hover:opacity-100 transition-opacity"
                  style={{ color: partner.color }}
                >
                  {partner.logo}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#ff6b00]/5 to-transparent" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Content */}
            <div>
              <span className="inline-block px-4 py-1.5 rounded-full bg-[#ff6b00]/10 border border-[#ff6b00]/30 text-[#ff6b00] text-sm font-medium mb-6">
                About SAKKUAZA
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
                Building Nigeria&apos;s <span className="text-[#ff6b00]">Digital Infrastructure</span>
              </h2>
              <p className="text-white/60 text-lg mb-8 leading-relaxed">
                SAKKUAZA is at the forefront of Nigeria&apos;s digital transformation, providing blockchain-powered identity solutions that connect citizens with essential services securely and efficiently.
              </p>
              
              <div className="space-y-4 mb-8">
                {[
                  "Official KYB Approved Partner of Sidra Clubs Blockchain",
                  "Providing KYC Verification Services for Users",
                  "Integrated with NIMC, MTN, Airtel & Pi Network",
                  "Enterprise-grade security and compliance"
                ].map((item, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#ff6b00] flex-shrink-0" />
                    <span className="text-white/80">{item}</span>
                  </div>
                ))}
              </div>

              <Button 
                size="lg"
                className="bg-[#ff6b00] hover:bg-[#ff8533] text-black font-semibold px-8 rounded-full transition-all duration-300 hover:scale-105"
              >
                Learn More
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </div>

            {/* Visual */}
            <div className="relative">
              <div className="aspect-square rounded-3xl bg-gradient-to-br from-[#ff6b00]/20 to-[#00d4ff]/10 p-1">
                <div className="w-full h-full rounded-3xl bg-[#111111] flex items-center justify-center relative overflow-hidden">
                  {/* Animated rings */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-48 h-48 border border-[#ff6b00]/20 rounded-full animate-pulse" />
                    <div className="absolute w-64 h-64 border border-[#ff6b00]/10 rounded-full animate-pulse delay-100" />
                    <div className="absolute w-80 h-80 border border-[#ff6b00]/5 rounded-full animate-pulse delay-200" />
                  </div>
                  
                  {/* Center logo */}
                  <div className="relative z-10 w-32 h-32 rounded-3xl bg-gradient-to-br from-[#ff6b00] to-[#ffa500] flex items-center justify-center text-5xl font-bold text-black animate-float">
                    S
                  </div>

                  {/* Floating partner icons */}
                  {partners.slice(0, 4).map((partner, index) => {
                    const positions = [
                      "top-8 left-8",
                      "top-8 right-8",
                      "bottom-8 left-8",
                      "bottom-8 right-8"
                    ]
                    return (
                      <div
                        key={index}
                        className={`absolute ${positions[index]} w-12 h-12 rounded-xl flex items-center justify-center text-xs font-bold animate-float`}
                        style={{ 
                          backgroundColor: `${partner.color}20`,
                          color: partner.color,
                          animationDelay: `${index * 0.5}s`
                        }}
                      >
                        {partner.logo}
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#ff6b00]/20 via-[#0a0a0a] to-[#00d4ff]/20" />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,107,0,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,107,0,0.05)_1px,transparent_1px)] bg-[size:40px_40px]" />

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            Ready to Join the <span className="text-[#ff6b00]">Digital Revolution</span>?
          </h2>
          <p className="text-white/60 text-lg mb-10 max-w-2xl mx-auto">
            Be part of Nigeria&apos;s fastest-growing blockchain ecosystem. Connect your identity, secure your assets, and unlock new possibilities.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              size="lg"
              className="bg-[#ff6b00] hover:bg-[#ff8533] text-black font-semibold px-10 py-6 text-lg rounded-full transition-all duration-300 hover:scale-105 hover:shadow-[0_0_50px_rgba(255,107,0,0.5)] w-full sm:w-auto"
            >
              Get Started Now
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="border-[#00d4ff]/30 text-[#00d4ff] hover:bg-[#00d4ff]/10 px-10 py-6 text-lg rounded-full w-full sm:w-auto bg-transparent"
            >
              Contact Sales
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 relative">
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Contact Info */}
            <div>
              <span className="inline-block px-4 py-1.5 rounded-full bg-[#00d4ff]/10 border border-[#00d4ff]/30 text-[#00d4ff] text-sm font-medium mb-6">
                Contact Us
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold mb-6">
                Let&apos;s Build <span className="text-[#00d4ff]">Together</span>
              </h2>
              <p className="text-white/60 mb-8">
                Have questions about our solutions? Want to partner with SAKKUAZA? We&apos;d love to hear from you.
              </p>

              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#ff6b00]/10 flex items-center justify-center">
                    <Building2 className="w-6 h-6 text-[#ff6b00]" />
                  </div>
                  <div>
                    <div className="text-sm text-white/50">Office</div>
                    <div className="font-medium">No.103, Palace Way, Tashan Lau, Jalingo</div>
                    <div className="text-sm text-white/50">Taraba State, Nigeria</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#ff6b00]/10 flex items-center justify-center">
                    <Zap className="w-6 h-6 text-[#ff6b00]" />
                  </div>
                  <div>
                    <div className="text-sm text-white/50">Email</div>
                    <Link href="mailto:sakkuazageneralservice@gmail.com" className="font-medium hover:text-[#ff6b00] transition-colors">
                      sakkuazageneralservice@gmail.com
                    </Link>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#ff6b00]/10 flex items-center justify-center">
                    <Users className="w-6 h-6 text-[#ff6b00]" />
                  </div>
                  <div>
                    <div className="text-sm text-white/50">Support</div>
                    <div className="font-medium">24/7 Available</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <ContactForm />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#222222]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div className="lg:col-span-1">
              <Link href="/" className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#ff6b00] to-[#ff8533] flex items-center justify-center font-bold text-black text-lg">
                  S
                </div>
                <span className="text-xl font-bold">
                  SAKKU<span className="text-[#ff6b00]">AZA</span>
                </span>
              </Link>
              <p className="text-white/50 text-sm">
                SAKKUAZA GENERAL SERVICES NIG LTD - Blockchain & Digital Identity Solutions for Nigeria&apos;s digital future.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold mb-4 text-white">Quick Links</h4>
              <div className="space-y-2">
                {["Features", "Partners", "About", "Contact"].map((item) => (
                  <Link
                    key={item}
                    href={`#${item.toLowerCase()}`}
                    className="block text-white/50 hover:text-[#ff6b00] transition-colors text-sm"
                  >
                    {item}
                  </Link>
                ))}
              </div>
            </div>

            {/* Partners */}
            <div>
              <h4 className="font-semibold mb-4 text-white">Partners</h4>
              <div className="space-y-2">
                {partners.map((partner) => (
                  <Link
                    key={partner.name}
                    href={partner.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-white/50 hover:text-[#ff6b00] transition-colors text-sm"
                  >
                    {partner.name}
                  </Link>
                ))}
              </div>
            </div>

            {/* Legal */}
            <div>
              <h4 className="font-semibold mb-4 text-white">Legal</h4>
              <div className="space-y-2">
                {["Privacy Policy", "Terms of Service", "Cookie Policy"].map((item) => (
                  <Link
                    key={item}
                    href="#"
                    className="block text-white/50 hover:text-[#ff6b00] transition-colors text-sm"
                  >
                    {item}
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="pt-8 border-t border-[#222222] flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-white/40 text-sm">
              &copy; {new Date().getFullYear()} SAKKUAZA GENERAL SERVICES NIG LTD. All rights reserved.
            </p>
            <div className="flex items-center gap-4">
              <span className="text-white/40 text-sm">Built with blockchain technology</span>
              <div className="w-2 h-2 bg-[#ff6b00] rounded-full animate-pulse" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
